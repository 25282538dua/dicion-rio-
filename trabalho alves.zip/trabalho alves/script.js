document.getElementById('Div').addEventListener('click', function() {
    let minhaDiv = document.getElementById('Arrested');

    if (minhaDiv.style.display === 'none') {
        minhaDiv.style.display = 'block';
    } 
    else {
        minhaDiv.style.display = 'none';
    }
    });
document.getElementById('Div2').addEventListener('click', function() {
    let minhaDiv = document.getElementById('Lieutenant');

    if (minhaDiv.style.display === 'none') {
        minhaDiv.style.display = 'block';
    } 
    else {
        minhaDiv.style.display = 'none';
    }
    });
document.getElementById('Div3').addEventListener('click', function() {
    let minhaDiv = document.getElementById('Bottle');

    if (minhaDiv.style.display === 'none') {
        minhaDiv.style.display = 'block';
    } 
    else {
        minhaDiv.style.display = 'none';
    }
    });
document.getElementById('Div4').addEventListener('click', function() {
    let minhaDiv = document.getElementById('City');

    if (minhaDiv.style.display === 'none') {
        minhaDiv.style.display = 'block';
    } 
    else {
        minhaDiv.style.display = 'none';
    }
});
document.getElementById('Div5').addEventListener('click', function() {
    let minhaDiv = document.getElementById('Heir');

    if (minhaDiv.style.display === 'none') {
    minhaDiv.style.display = 'block';
    } 
    else {
    minhaDiv.style.display = 'none';
    }
});
document.getElementById('Div6').addEventListener('click', function() {
    let minhaDiv = document.getElementById('Investigating');

    if (minhaDiv.style.display === 'none') {
        minhaDiv.style.display = 'block';
    } 
    else {
        minhaDiv.style.display = 'none';
    }
    });
document.getElementById('Div7').addEventListener('click', function() {
    let minhaDiv = document.getElementById('Strength');

    if (minhaDiv.style.display === 'none') {
        minhaDiv.style.display = 'block';
    } 
    else {
        minhaDiv.style.display = 'none';
    }
});
document.getElementById('Div8').addEventListener('click', function() {
    let minhaDiv = document.getElementById('Neighborhood');

    if (minhaDiv.style.display === 'none') {
        minhaDiv.style.display = 'block';
    } 
    else {
        minhaDiv.style.display = 'none';
    }
    });
document.getElementById('Div9').addEventListener('click', function() {
    let minhaDiv = document.getElementById('Worried');

    if (minhaDiv.style.display === 'none') {
        minhaDiv.style.display = 'block';
    } 
    else {
        minhaDiv.style.display = 'none';
    }
});
document.getElementById('Div10').addEventListener('click', function() {
    let minhaDiv = document.getElementById('Ate');

    if (minhaDiv.style.display === 'none') {
        minhaDiv.style.display = 'block';
    } 
    else {
        minhaDiv.style.display = 'none';
    }
});


function abrirTexto(){
    let esco = document.getElementById("escondido")
    if(esco.style.display === "none")
        esco.style.display = "block"
    else{
        esco.style.display = "none";
    }
}